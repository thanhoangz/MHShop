﻿(function () {
    angular.module('MHShop.common', ['ui.router', 'ngBootbox','ngCkeditor'])
})();